///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// Allow RGB texture rows that are not aligned to 4-byte boundaries
		glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glDeleteTextures(1, &m_textureIDs[i].ID);
	}

	m_loadedTextures = 0;
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(bFound);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  This method defines the material properties used by
 *  objects in the firefighter helmet scene.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	OBJECT_MATERIAL forestMaterial;

	// Forest floor uses a dark, mostly matte material so the
// texture remains visible while responding to scene lighting.
	forestMaterial.ambientColor = glm::vec3(0.15f, 0.15f, 0.15f);
	forestMaterial.ambientStrength = 0.10f;
	forestMaterial.diffuseColor = glm::vec3(0.35f, 0.35f, 0.35f);
	forestMaterial.specularColor = glm::vec3(0.08f, 0.08f, 0.08f);
	forestMaterial.shininess = 4.0f;
	forestMaterial.tag = "forestMaterial";

	m_objectMaterials.push_back(forestMaterial);

	// Define material for the firefighter helmet
	OBJECT_MATERIAL helmetMaterial;

	// Helmet material keeps the texture visible while allowing
	// moderate highlights from the scene lighting.
	helmetMaterial.ambientColor = glm::vec3(0.15f, 0.15f, 0.15f);
	helmetMaterial.ambientStrength = 0.15f;
	helmetMaterial.diffuseColor = glm::vec3(0.40f, 0.40f, 0.40f);
	helmetMaterial.specularColor = glm::vec3(0.20f, 0.20f, 0.20f);
	helmetMaterial.shininess = 8.0f;
	helmetMaterial.tag = "helmetMaterial";

	// Add the helmet material to the collection
	m_objectMaterials.push_back(helmetMaterial);
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method sets up the light sources used to illuminate
 *  the firefighter helmet and surrounding ground plane.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// Enable custom lighting in the shaders
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// Keep the primary and secondary lights as regular lights
	m_pShaderManager->setBoolValue(
		"lightSources[0].isSpotlight", false);

	m_pShaderManager->setBoolValue(
		"lightSources[1].isSpotlight", false);


	// Primary light source
	// Positioned above and slightly in front of the helmet
	m_pShaderManager->setVec3Value(
		"lightSources[0].position",
		-3.0f, 6.0f, 4.0f);

	// Low ambient light keeps shadowed areas visible
	m_pShaderManager->setVec3Value(
		"lightSources[0].ambientColor",
		0.45f, 0.45f, 0.45f);

	// White diffuse light illuminates the textures
	m_pShaderManager->setVec3Value(
		"lightSources[0].diffuseColor",
		1.0f, 1.0f, 1.0f);

	// Specular light produces highlights on the surfaces
	m_pShaderManager->setVec3Value(
		"lightSources[0].specularColor",
		1.0f, 1.0f, 1.0f);

	// Set the light strength
	m_pShaderManager->setFloatValue(
		"lightSources[0].focalStrength",
		32.0f);

	m_pShaderManager->setFloatValue(
		"lightSources[0].specularIntensity",
		0.8f);

	// Secondary fill light
	// Positioned on the opposite side to reduce dark shadows
	m_pShaderManager->setVec3Value(
		"lightSources[1].position",
		4.0f, 3.0f, 2.0f);

	// Soft ambient contribution from the secondary light
	m_pShaderManager->setVec3Value(
		"lightSources[1].ambientColor",
		0.15f, 0.15f, 0.15f);

	// Warm secondary light adds a subtle amber tint
	// while keeping the primary white light dominant
	m_pShaderManager->setVec3Value(
		"lightSources[1].diffuseColor",
		0.45f, 0.30f, 0.15f);

	// Small specular contribution
	m_pShaderManager->setVec3Value(
		"lightSources[1].specularColor",
		0.30f, 0.30f, 0.30f);

	m_pShaderManager->setFloatValue(
		"lightSources[1].focalStrength",
		24.0f);

	m_pShaderManager->setFloatValue(
		"lightSources[1].specularIntensity",
		0.30f);


	// ==========================================
	// Flashlight Spotlight - Light Source 2
	// ==========================================

	// Enable spotlight mode
	m_pShaderManager->setBoolValue(
		"lightSources[2].isSpotlight", true);

	// Position light above the flashlight head
	m_pShaderManager->setVec3Value(
		"lightSources[2].position",
		3.5f, 1.58f, 0.5f);

	// Point the flashlight straight upward
	m_pShaderManager->setVec3Value(
		"lightSources[2].direction",
		0.0f, 1.0f, 0.0f);

	// No ambient light outside the beam
	m_pShaderManager->setVec3Value(
		"lightSources[2].ambientColor",
		0.0f, 0.0f, 0.0f);

	// Soft warm-white flashlight illumination
	m_pShaderManager->setVec3Value(
		"lightSources[2].diffuseColor",
		0.90f, 0.96f, 1.0f);

	m_pShaderManager->setVec3Value(
		"lightSources[2].specularColor",
		0.7f, 0.7f, 0.6f);

	// Spotlight cutoff angles (stored as cosines)
	m_pShaderManager->setFloatValue(
		"lightSources[2].innerCutoff",
		glm::cos(glm::radians(12.5f)));

	m_pShaderManager->setFloatValue(
		"lightSources[2].outerCutoff",
		glm::cos(glm::radians(20.0f)));

	m_pShaderManager->setFloatValue(
		"lightSources[2].focalStrength",
		32.0f);

	m_pShaderManager->setFloatValue(
		"lightSources[2].specularIntensity",
		0.4f);

	// Disable unused fourth light source
	m_pShaderManager->setBoolValue(
		"lightSources[3].isSpotlight", false);

	m_pShaderManager->setVec3Value(
		"lightSources[3].ambientColor",
		0.0f, 0.0f, 0.0f);

	m_pShaderManager->setVec3Value(
		"lightSources[3].diffuseColor",
		0.0f, 0.0f, 0.0f);

	m_pShaderManager->setVec3Value(
		"lightSources[3].specularColor",
		0.0f, 0.0f, 0.0f);

	m_pShaderManager->setFloatValue(
		"lightSources[3].specularIntensity",
		0.0f);
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/

void SceneManager::PrepareScene() {
	// Load firefighter helmet yellow texture
	CreateGLTexture("textures/CS 330 Mod 5 FF helmet.jpg", "helmetYellow");

	// Load black leather texture for the helmet band
	CreateGLTexture("textures/CS 330 Mod 5 FF Band.jpg", "helmetBand");

	// Load red leather texture for the front shield
	CreateGLTexture("textures/CS 330 Mod 5 FF Shield.jpg", "helmetShield");

	// Load forest floor texture
	CreateGLTexture("textures/CS 330 Mod 5 Floor.jpg", "forestFloor");

	// Bind loaded textures to OpenGL texture slots
	BindGLTextures();
	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	m_basicMeshes->LoadPlaneMesh();

	// Load meshes needed to construct objects in the 3D scene
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadPyramid4Mesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadConeMesh(); 

	// Define material properties for objects in the scene
	DefineObjectMaterials();

	// Set up lighting for the firefighter helmet scene
	SetupSceneLights();
}
/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene() {
		// Apply the scene lighting before rendering objects
		SetupSceneLights();

		// declare the variables for the transformations
		glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply material properties so the plane responds to the scene lighting
	SetShaderMaterial("forestMaterial");

	// Apply forest floor texture to the ground plane
	SetShaderTexture("forestFloor");

	// Tile the forest floor texture across the large ground surface
	SetTextureUVScale(8.0f, 8.0f);

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
	/****************************************************************/

	/*
	* Firefighter Helmet - Crown
	* Scale and position a sphere to create the rounded upper portion of the helmet.
	*/

	// Scale the sphere into the shape of the helmet crown
	scaleXYZ = glm::vec3(2.2f, 1.5f, 1.7f);

	// No rotation needed for the crown
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Position the helmet crown above the plane
	positionXYZ = glm::vec3(0.0f, 1.6f, 0.0f);

	// Apply transformations
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply yellow texture to the helmet crown
	SetShaderTexture("helmetYellow");

	// Apply helmet material for lighting and reflection
	SetShaderMaterial("helmetMaterial");

	// Tile the texture to prevent excessive stretching
	SetTextureUVScale(2.0f, 2.0f);

	//Draw the helmet crown
	m_basicMeshes->DrawSphereMesh();

	/*
	* Firefighter Helmet - Brim
	* Scale and position a box to create the brim of the helmet.
	*/

	// Scale the box into the wide helmet brim
	scaleXYZ = glm::vec3(5.0f, 0.12f, 3.2f);

	// Keep the brim horizontal
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Position the helmet brim below the crown
	positionXYZ = glm::vec3(0.0f, 0.72f, 0.0f);

	// Apply transformations
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply the same yellow texture to the helmet brim
	SetShaderTexture("helmetYellow");

	// Apply helmet material for lighting
	SetShaderMaterial("helmetMaterial");

	// Tile the texture across the wide brim
	SetTextureUVScale(3.0f, 2.0f);

	// Draw the helmet brim
	m_basicMeshes->DrawBoxMesh();

	/*
	* Firefighter Helmet - Reflective Band
	* * Add a dark reflective band across the crown
	*/

	//Scale the box into a thin reflective band
	scaleXYZ = glm::vec3(3.9f, 0.30f, 0.30f);

	//Keep the band horizontal
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	//Position the reflective band across the lower portion of the crown of the helmet
	positionXYZ = glm::vec3(0.0f, 1.50f, 1.55f);

	// Apply transformations
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply black leather texture to the reflective helmet band
	SetShaderTexture("helmetBand");

	// Apply helmet material for lighting
	SetShaderMaterial("helmetMaterial");

	// Tile the leather texture across the long narrow band
	SetTextureUVScale(4.0f, 1.0f);

	// Draw the band across the crown of the helmet
	m_basicMeshes->DrawBoxMesh();

	/*
	* Firefighter Helmet -  Front Shield Main Body
	* Create the main body of the front shield using a box shape.
	*/

	// Scale the box into the main shield body
	scaleXYZ = glm::vec3(1.55f, 0.90f, 0.15f);

	// Keep the main shield body upright
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Position the shield on the front of the helmet
	positionXYZ = glm::vec3(0.0f, 2.20f, 1.75f);

	// Apply transformations
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply matte red leather texture to the shield body
	SetShaderTexture("helmetShield");

	// Apply helmet material for lighting
	SetShaderMaterial("helmetMaterial");

	// Keep the leather grain appropriately sized on the shield
	SetTextureUVScale(1.0f, 1.0f);

	// Draw the main shield body
	m_basicMeshes->DrawBoxMesh();

	/*
	* Firefighter Helmet - Front Shield Top Section
	* * Use a pyramid shape to create the top section
	*/

	// Scale the pyramid into a thin pointed shield top
	scaleXYZ = glm::vec3(1.55f, 0.65f, 0.20f);

	// Keep the pyramid upright so the pointed face is visible
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Position the pyramid above the rectangular shield body
	positionXYZ = glm::vec3(0.0f, 2.80f, 1.78f);

	// Apply scale, rotation, and translation
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply the same matte red leather texture to the shield top
	SetShaderTexture("helmetShield");

	// Apply helmet material for lighting
	SetShaderMaterial("helmetMaterial");

	// Match the texture scale used on the shield body
	SetTextureUVScale(1.0f, 1.0f);

	// Draw the pointed shield top
	m_basicMeshes->DrawPyramid4Mesh();

	/* ==========================================
	 * Firefighter Fire Extinguisher 
	 * ========================================== */

	 // 1. Main Body (Red cylinder)
	scaleXYZ = glm::vec3(0.75f, 1.8f, 0.75f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-4.5f, 0.95f, 0.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// Apply solid firefighter red to the extinguisher body
	SetShaderColor(0.85f, 0.05f, 0.05f, 1.0f);

	// Apply material properties for lighting
	SetShaderMaterial("helmetMaterial");

	m_basicMeshes->DrawCylinderMesh();


	// 2. Shoulder Cap (Dark top)
	scaleXYZ = glm::vec3(0.75f, 0.35f, 0.75f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-4.5f, 2.75f, 0.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("helmetBand");
	SetShaderMaterial("helmetMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawSphereMesh();


	// 3. Valve Neck
	scaleXYZ = glm::vec3(0.25f, 0.3f, 0.25f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-4.5f, 3.05f, 0.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("helmetBand");
	SetShaderMaterial("helmetMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();


	// 4. Carrying Handle / Lever
	scaleXYZ = glm::vec3(0.15f, 0.08f, 0.5f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-4.3f, 3.25f, 0.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("helmetBand");
	SetShaderMaterial("helmetMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();


	// 5. Discharge Hose / Nozzle
	scaleXYZ = glm::vec3(0.08f, 0.4f, 0.08f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 90.0f;
	positionXYZ = glm::vec3(-4.2f, 3.0f, 0.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("helmetBand");
	SetShaderMaterial("helmetMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();



	/* ==========================================
	 * Firefighter Flashlight (Object #4 - Proportioned)
	 * ========================================== */

	 // 1. Flashlight Main Body (Taller, well-proportioned cylinder)
	scaleXYZ = glm::vec3(0.3f, 1.2f, 0.3f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(3.5f, 0.6f, 0.5f); // Positioned nicely on the right

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("helmetBand"); // Black casing
	SetShaderMaterial("helmetMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();


	// 2. Flashlight Head / Bezel (Slightly wider top section)
	scaleXYZ = glm::vec3(0.4f, 0.4f, 0.4f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(3.5f, 1.35f, 0.5f); // Sits right on top of the body

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("helmetBand"); // Matching textured look
	SetShaderMaterial("helmetMaterial");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();


	// ==========================================
	// Flashlight Beam - Upward Facing Cone
	// ==========================================

	// Narrow end starts above the flashlight head
	// Wide end extends upward
	scaleXYZ = glm::vec3(1.5f, 8.0f, 1.5f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 180.0f;

	// Position the inverted cone so its tip starts at Y = 1.58
	positionXYZ = glm::vec3(3.5f, 9.58f, 0.5f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);


	// Enable transparency for the flashlight beam
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	// Prevent the transparent beam from blocking objects behind it
	glDepthMask(GL_FALSE);


	// Temporarily disable lighting to test the flashlight beam
	m_pShaderManager->setBoolValue(g_UseLightingName, false);

	// Bright, cool-white LED flashlight beam
	SetShaderColor(0.90f, 0.96f, 1.0f, 0.30f);


	// Enable the gradual fade for the flashlight beam
	m_pShaderManager->setBoolValue("bUseBeamFade", true);
	m_pShaderManager->setFloatValue("beamBottomY", 1.58f);
	m_pShaderManager->setFloatValue("beamTopY", 9.58f);

	// Draw the flashlight beam
	m_basicMeshes->DrawConeMesh();

	// Disable the fading effect
	m_pShaderManager->setBoolValue("bUseBeamFade", false);

	// Restore normal rendering settings
	glDepthMask(GL_TRUE);
	glDisable(GL_BLEND);

	// Restore lighting
	m_pShaderManager->setBoolValue(g_UseLightingName, true);




}