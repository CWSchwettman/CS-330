#version 440 core

struct Material 
{
    vec3 ambientColor;
    float ambientStrength;
    vec3 diffuseColor;
    vec3 specularColor;
    float shininess;
}; 


struct LightSource
{
    vec3 position;
    vec3 ambientColor;
    vec3 diffuseColor;
    vec3 specularColor;
    float focalStrength;
    float specularIntensity;

    // Spotlight properties
    bool isSpotlight;
    vec3 direction;
    float innerCutoff;
    float outerCutoff;
};


#define TOTAL_LIGHTS 4

in vec3 fragmentPosition;
in vec3 fragmentVertexNormal;
in vec2 fragmentTextureCoordinate;

out vec4 outFragmentColor;

uniform bool bUseTexture=false;
uniform bool bUseLighting=false;
uniform vec4 objectColor = vec4(1.0f);
uniform sampler2D objectTexture;
uniform vec3 viewPosition;
uniform vec2 UVscale = vec2(1.0f, 1.0f);
uniform LightSource lightSources[TOTAL_LIGHTS];
uniform Material material;
uniform bool bUseBeamFade = false;
uniform float beamBottomY = 1.58;
uniform float beamTopY = 9.58;
uniform float beamEdgeSoftness = 0.15;

// function prototypes

vec3 CalcLightSource(LightSource light, vec3 lightNormal,
                     vec3 vertexPosition, vec3 viewDirection)
{
    // Calculate ambient lighting
    vec3 ambient = light.ambientColor +
        (material.ambientColor * material.ambientStrength);

    // Calculate light direction
    vec3 lightDirection = normalize(light.position - vertexPosition);

    // Calculate diffuse lighting
    float impact = max(dot(lightNormal, lightDirection), 0.0);
    vec3 diffuse = impact * light.diffuseColor * material.diffuseColor;

    // Calculate specular lighting
    vec3 reflectDir = reflect(-lightDirection, lightNormal);
    float specularComponent = pow(
        max(dot(viewDirection, reflectDir), 0.0), 32.0);

    vec3 specular = (light.specularIntensity * material.shininess) *
        specularComponent * material.specularColor;

    // Distance attenuation
    float distance = length(light.position - vertexPosition);
    float attenuation = 1.0 /
        (1.0 + 0.09 * distance + 0.032 * distance * distance);

    // Spotlight intensity
    float intensity = 1.0;

    if (light.isSpotlight)
    {
        // Compare the spotlight direction with the fragment direction
        float theta = dot(
            normalize(vertexPosition - light.position),
            normalize(light.direction));

        // Smooth transition between inner and outer cutoff
        float epsilon = max(light.innerCutoff - light.outerCutoff, 0.0001);
        intensity = clamp(
            (theta - light.outerCutoff) / epsilon,
            0.0, 1.0);

        // Prevent ambient lighting outside the spotlight cone
        ambient = vec3(0.0);
    }

    // Apply spotlight intensity to diffuse and specular lighting
    return ambient + attenuation * intensity * (diffuse + specular);
}


void main()
{
    if (bUseLighting == true)
    {
        // Normalize the surface normal and camera direction
        vec3 lightNormal = normalize(fragmentVertexNormal);
        vec3 viewDirection = normalize(viewPosition - fragmentPosition);

        // Accumulate lighting from all configured light sources
        vec3 phongResult = vec3(0.0);

        for (int i = 0; i < TOTAL_LIGHTS; i++)
        {
            phongResult += CalcLightSource(
                lightSources[i],
                lightNormal,
                fragmentPosition,
                viewDirection);
        }

        // Apply lighting to textured objects
        if (bUseTexture == true)
        {
            vec4 textureColor = texture(
                objectTexture,
                fragmentTextureCoordinate * UVscale);

            outFragmentColor = vec4(
                phongResult * textureColor.rgb,
                textureColor.a);
        }
        else
        {
            // Apply lighting to solid-colored objects
            outFragmentColor = vec4(
                phongResult * objectColor.rgb,
                objectColor.a);
        }
    }
    else
    {
        // Render without custom lighting
        if (bUseTexture == true)
        {
            outFragmentColor = texture(
                objectTexture,
                fragmentTextureCoordinate * UVscale);
        }
        else
        {
            outFragmentColor = objectColor;
        }
    }


    // Gradually fade the flashlight beam as it rises
    if (bUseBeamFade)
    {
        // Calculate height between the flashlight and beam top
        float beamHeight = max(beamTopY - beamBottomY, 0.001);

        float heightFactor = clamp(
            (fragmentPosition.y - beamBottomY) / beamHeight,
            0.0, 1.0);

        // Stronger near the flashlight, softer toward the top
        float fade = 1.0 - smoothstep(0.35, 1.0, heightFactor);

        // Apply the vertical fade to the flashlight beam
	outFragmentColor.a *= fade;
    }

}

